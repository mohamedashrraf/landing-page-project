# Landing Page Project udacity


javascript minapulate the code and create navbar not html

___


This project has the scope of converting a static web page in a single interactive page.

It uses javascript to dynamically create navbar links based on the content, when a section is in the viewport it show the active state of that section.


During the scrolling the navbar is automatically hidden and showed according the direction of the scrolling.


When scrolling past a configurable buffer, a new element will appear close to the bottom of the page. This element can be used by the users to scroll to the very top of the page.